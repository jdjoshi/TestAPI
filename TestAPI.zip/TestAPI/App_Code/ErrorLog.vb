﻿Imports System.IO

Public Class ErrorLog
    Public Shared Sub RequestLog(ByVal IP As String, ByVal ParameterXML As String)
        Try
            Dim dirErrorLog As New DirectoryInfo(HttpContext.Current.Server.MapPath("~\RequestLogs\"))
            If Not dirErrorLog.Exists Then
                dirErrorLog.Create()
            End If

            Dim fs As IO.FileStream
            fs = New IO.FileStream(HttpContext.Current.Server.MapPath("~\RequestLogs\") & GetTodayDate() & ".txt", IO.FileMode.Append, IO.FileAccess.Write)
            Dim sw As New IO.StreamWriter(fs)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------" & vbCrLf)
            sw.WriteLine("IP Address : " & IP & "  ParameterXML : " & ParameterXML)
            sw.Write(vbCrLf & vbCrLf)
            sw.Close()
            HttpContext.Current.Server.ClearError()
        Catch ex As Exception
            HttpContext.Current.Response.Write(ex.Message)
        End Try
    End Sub

    Public Shared Sub LogError(ByVal MyError As Exception, ByVal UserId As String)
        Try
            If MyError.ToString = "System.Threading.ThreadAbortException: Thread was being aborted." Then
                Return
            End If
            Dim dirErrorLog As New DirectoryInfo(HttpContext.Current.Server.MapPath("~\Logs\"))
            If Not dirErrorLog.Exists Then
                dirErrorLog.Create()
            End If

            Dim fs As IO.FileStream
            fs = New IO.FileStream(HttpContext.Current.Server.MapPath("~\Logs\") & GetTodayDate() & ".txt", IO.FileMode.Append, IO.FileAccess.Write)
            Dim sw As New IO.StreamWriter(fs)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------" & vbCrLf)
            sw.WriteLine("UserID : " & UserId)
            sw.WriteLine("Exception : " & MyError.ToString)
            sw.WriteLine("Stack Trace: ")
            sw.Write(MyError.StackTrace & vbCrLf)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------")
            sw.Write(vbCrLf & vbCrLf)
            sw.Close()
            HttpContext.Current.Server.ClearError()
        Catch ex As Exception
            HttpContext.Current.Response.Write(ex.Message)
        End Try
    End Sub

    Public Shared Sub LogError(ByVal MyError As Exception, ByVal lable As String, ByVal val As String)
        Try
            If MyError.ToString = "System.Threading.ThreadAbortException: Thread was being aborted." Then
                Return
            End If
            Dim dirErrorLog As New DirectoryInfo(HttpContext.Current.Server.MapPath("~\Logs\"))
            If Not dirErrorLog.Exists Then
                dirErrorLog.Create()
            End If

            Dim fs As IO.FileStream
            fs = New IO.FileStream(HttpContext.Current.Server.MapPath("~\Logs\") & GetTodayDate() & ".txt", IO.FileMode.Append, IO.FileAccess.Write)
            Dim sw As New IO.StreamWriter(fs)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------" & vbCrLf)
            sw.WriteLine("Error For  : " & lable & ": " & val & vbCrLf)
            sw.WriteLine("Exception : " & MyError.ToString)
            sw.WriteLine("Stack Trace: ")
            sw.Write(MyError.StackTrace & vbCrLf)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------")
            sw.Write(vbCrLf & vbCrLf)
            sw.Close()
            HttpContext.Current.Server.ClearError()
        Catch ex As Exception
            HttpContext.Current.Response.Write(ex.Message)
        End Try
    End Sub

    Public Shared Sub LogMessage(ByVal Message As String)
        Try

            Dim dirErrorLog As New DirectoryInfo(HttpContext.Current.Server.MapPath("~\Logs\"))
            If Not dirErrorLog.Exists Then
                dirErrorLog.Create()
            End If

            Dim fs As IO.FileStream
            fs = New IO.FileStream(HttpContext.Current.Server.MapPath("~\Logs\") & GetTodayDate() & ".txt", IO.FileMode.Append, IO.FileAccess.Write)
            Dim sw As New IO.StreamWriter(fs)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------" & vbCrLf)

            sw.WriteLine(" Message : " & Message.ToString)
            sw.Write("------------------------------------------------------" & Now.ToString & "------------------------------------")
            sw.Write(vbCrLf & vbCrLf)
            sw.Close()

        Catch ex As Exception
            HttpContext.Current.Response.Write(ex.Message)
        End Try
    End Sub

    Private Shared Function GetTodayDate() As String
        Return Now.Year & "_" & Now.Month & "_" & Now.Day
    End Function

End Class
