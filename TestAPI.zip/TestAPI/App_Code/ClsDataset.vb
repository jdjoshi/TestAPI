﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail
Imports TestAPI


Public Class ClsDataset
    Public Function GetConnectionString() As String
        Dim cstring As String = ""
        Try
            cstring = System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStr").ToString()
        Catch ex As Exception
            ErrorLog.LogError(ex, ex.StackTrace, "GetConnectionString")
        End Try
        Return cstring
    End Function
    Public Function GetProcedure(ByVal SP As String) As String
        Dim cstring As String = ""
        Try
            cstring = System.Configuration.ConfigurationManager.AppSettings(SP).ToString()
        Catch ex As Exception
            ErrorLog.LogError(ex, "GetProcedure", "GetProcedure")
        End Try
        Return cstring
    End Function

    Public Function APIGetUserInfo() As DataSet
        Dim Ds As New DataSet
        Try
            Ds = SQLHelper.ExecuteDataset(GetConnectionString(), CommandType.StoredProcedure, GetProcedure("sp_APIGetUserInfo"))
        Catch ex As Exception
            ErrorLog.LogError(ex, ex.StackTrace, "APIGetUserInfo")
        End Try
        Return Ds
    End Function

    Public Function strToInt(ByVal Val As String) As Integer
        Dim Result As Integer = 0
        Try
            If Val <> "" Then
                Result = Convert.ToInt16(Val)
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "strToInt")
        End Try

        Return Result
    End Function

    Public Function strToInt32(ByVal Val As String) As Int32
        Dim Result As Int32 = 0
        Try
            If Val <> "" Then
                Result = Convert.ToInt32(Val)
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "strToInt32")
        End Try

        Return Result
    End Function

    Public Function strToInt64(ByVal Val As String) As Int64
        Dim Result As Int64 = 0
        Try
            If Val <> "" Then
                Result = Convert.ToInt64(Val)
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "strToInt64")
        End Try

        Return Result
    End Function

    Public Function strToDate(ByVal Val As String) As DateTime
        Dim Result As DateTime = New DateTime(1900, 1, 1)
        Try
            If Val <> "" Then
                Result = Convert.ToDateTime(Val)
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "strToDate")
        End Try

        Return Result
    End Function

    Public Function strToDouble(ByVal Val As String) As Double
        Dim Result As Double = 0
        Try
            If Val <> "" Then
                Result = Convert.ToDouble(Val)
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "strToDouble")
        End Try

        Return Result
    End Function

    Public Function chkDataSet(ByVal Ds As DataSet, Optional Tablecount As Integer = 0) As Boolean
        Dim Result As Boolean = False
        Try
            If Ds.Tables IsNot Nothing Then
                If Ds.Tables.Count > Tablecount Then
                    If Ds.Tables(Tablecount).Rows.Count > 0 Then
                        Result = True
                    End If
                End If
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "chkDataSet")
        End Try

        Return Result
    End Function

    Public Function chkDataTable(ByVal Dt As DataTable) As Boolean
        Dim Result As Boolean = False
        Try
            If Dt IsNot Nothing Then
                If Dt.Rows.Count > 0 Then
                    Result = True
                End If
            End If
        Catch Ex As Exception
            ErrorLog.LogError(Ex, Ex.StackTrace, "chkDataTable")
        End Try

        Return Result
    End Function
End Class
