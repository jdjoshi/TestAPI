﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports System.Xml

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
<ToolboxItem(False)>
Public Class TestAPI
    Inherits System.Web.Services.WebService
    Dim Obj As New ClsDataset


    <WebMethod()>
    Public Function GetUserInfo() As String
        Dim Strxml As String = ""
        Try
            Dim Obj As New ClsDataset
            Dim Ds As New DataSet
            Ds = Obj.APIGetUserInfo()
            If (Not Ds Is Nothing) Then
                If (Not Ds.Tables Is Nothing) Then
                    If (Ds.Tables(0).Rows.Count > 0) Then
                        Strxml = XMLGenerate(Ds, "RMAList")
                    End If
                End If
            End If

            If (Strxml = "") Then
                Strxml = WriteErr("CreatedDate", System.DateTime.Now, "MessageId", "Message")
            End If

        Catch ex As Exception
            ErrorLog.LogError(ex, "GetUserInfo", "GetUserInfo")
        End Try
        Return Strxml
    End Function


    Private Sub RequestLog(ByVal IP As String, ByVal ParamXML As String)
        Try
            ErrorLog.RequestLog(IP, ParamXML)
        Catch ex As Exception
            ErrorLog.LogError(ex, "Function Name", "RequestLog")
        End Try
    End Sub

    Private Function XMLGenerate(ByVal Ds As DataSet, ByVal Nameofmethod As String) As String
        Dim Strxml As String = ""
        Try
            Dim Rowid As Integer = 0
            While (Rowid < Ds.Tables(0).Rows.Count)
                Dim XMLdata As StringWriter = New StringWriter()
                Dim writer As New XmlTextWriter(XMLdata)
                writer.WriteStartElement("UserInfo")
                Dim Col As Integer = 0
                While (Col < Ds.Tables(0).Columns.Count)
                    writer = WriteNode(writer, Ds.Tables(0).Columns(Col).ColumnName, Convert.ToString(Ds.Tables(0).Rows(Rowid)(Col)))
                    Col = Col + 1
                End While
                writer.WriteEndElement()
                writer.Close()
                Strxml = Strxml & XMLdata.ToString()
                XMLdata.Close()
                Rowid = Rowid + 1
            End While
            Dim XMLdataheader As StringWriter = New StringWriter()
            Dim xmlwriter As New XmlTextWriter(XMLdataheader)
            xmlwriter = WriteNode(xmlwriter, Nameofmethod, "Strxml")
            Strxml = XMLdataheader.ToString().Replace("Strxml", Strxml)
            XMLdataheader.Close()
        Catch ex As Exception
            ErrorLog.LogError(ex, "Function Name", "XMLGenerate")
        End Try
        Return Strxml
    End Function
    Private Function WriteNode(ByVal Writer As XmlTextWriter, ByVal Name As String, ByVal val As String) As XmlTextWriter
        Try
            Writer.WriteStartElement(Name)
            Writer.WriteString(val)
            Writer.WriteEndElement()
        Catch ex As Exception
            ErrorLog.LogError(ex, "Function Name", "WriteNode")
        End Try
        Return Writer
    End Function
    Private Function WriteErr(ByVal lable1 As String, ByVal Val1 As String, ByVal lable2 As String, ByVal Val2 As String) As String
        Dim Strxml As String = ""
        Try
            Dim XMLdata As StringWriter = New StringWriter()
            Dim writer As New XmlTextWriter(XMLdata)
            Dim writerID As New XmlTextWriter(XMLdata)
            writer.WriteStartElement("Sales")
            writer.WriteStartElement("Error")
            writer = WriteNode(writer, lable1, Val1)
            writer = WriteNode(writer, lable2, Val2)
            writer.WriteEndElement()
            writer.WriteEndElement()
            Strxml = XMLdata.ToString()
        Catch ex As Exception
            ErrorLog.LogError(ex, "Function Name", "WriteErr")
        End Try
        Return Strxml
    End Function
   
End Class